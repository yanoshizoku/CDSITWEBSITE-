import { useEffect, useState } from 'react'
import { GoogleMap, useJsApiLoader, Marker } from '@react-google-maps/api'

const MapComponent = () => {
  // This is a simplified version that uses a placeholder for the API key
  // In a real application, you would use an environment variable
  const [mapLoaded, setMapLoaded] = useState(false)
  
  useEffect(() => {
    // Simulate map loading
    const timer = setTimeout(() => {
      setMapLoaded(true)
    }, 1000)
    
    return () => clearTimeout(timer)
  }, [])
  
  const center = {
    lat: 25.7617,
    lng: -80.1918
  }
  
  return (
    <div className="w-full h-[400px] rounded-lg overflow-hidden shadow-lg">
      {mapLoaded ? (
        <iframe
          src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3592.5496932229906!2d-80.19673532432648!3d25.76543427785072!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x88d9b69c4cf7d4f9%3A0xb99f5f97e0b0e62!2s175%20SW%207th%20St%2C%20Miami%2C%20FL%2033130!5e0!3m2!1sen!2sus!4v1680123456789!5m2!1sen!2sus"
          width="100%"
          height="100%"
          style={{ border: 0 }}
          allowFullScreen=""
          loading="lazy"
          referrerPolicy="no-referrer-when-downgrade"
          title="CDS IT Consulting office location"
        ></iframe>
      ) : (
        <div className="w-full h-full bg-gray-200 flex items-center justify-center">
          <div className="animate-pulse flex flex-col items-center">
            <svg 
              className="w-12 h-12 text-gray-400" 
              fill="none" 
              stroke="currentColor" 
              viewBox="0 0 24 24" 
              xmlns="http://www.w3.org/2000/svg"
            >
              <path 
                strokeLinecap="round" 
                strokeLinejoin="round" 
                strokeWidth={2} 
                d="M9 20l-5.447-2.724A1 1 0 013 16.382V5.618a1 1 0 011.447-.894L9 7m0 13l6-3m-6 3V7m6 10l4.553 2.276A1 1 0 0021 18.382V7.618a1 1 0 00-.553-.894L15 4m0 13V4m0 0L9 7" 
              />
            </svg>
            <p className="mt-2 text-gray-600">Loading map...</p>
          </div>
        </div>
      )}
    </div>
  )
}

export default MapComponent