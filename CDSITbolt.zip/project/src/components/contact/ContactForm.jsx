import { useState } from 'react'
import { useForm } from 'react-hook-form'
import { motion } from 'framer-motion'

const ContactForm = () => {
  const { register, handleSubmit, formState: { errors }, reset } = useForm()
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [formSubmitted, setFormSubmitted] = useState(false)
  
  const onSubmit = async (data) => {
    setIsSubmitting(true)
    
    // Simulate form submission
    setTimeout(() => {
      console.log('Form data:', data)
      setIsSubmitting(false)
      setFormSubmitted(true)
      reset()
      
      // Reset success message after 5 seconds
      setTimeout(() => {
        setFormSubmitted(false)
      }, 5000)
    }, 1500)
  }
  
  return (
    <motion.div 
      className="bg-white rounded-lg shadow-lg p-8"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.2 }}
    >
      <h3 className="text-2xl font-bold text-primary-500 mb-6">Send Us a Message</h3>
      
      {formSubmitted ? (
        <div className="bg-green-50 text-green-700 p-4 rounded-md mb-6">
          <p className="font-medium">Thank you for your message!</p>
          <p>We'll get back to you as soon as possible.</p>
        </div>
      ) : null}
      
      <form onSubmit={handleSubmit(onSubmit)}>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
          <div>
            <label htmlFor="firstName" className="form-label">First Name</label>
            <input
              type="text"
              id="firstName"
              className={`form-input ${errors.firstName ? 'border-error-500 focus:border-error-500 focus:ring-error-500' : ''}`}
              {...register('firstName', { required: 'First name is required' })}
            />
            {errors.firstName && <p className="form-error">{errors.firstName.message}</p>}
          </div>
          
          <div>
            <label htmlFor="lastName" className="form-label">Last Name</label>
            <input
              type="text"
              id="lastName"
              className={`form-input ${errors.lastName ? 'border-error-500 focus:border-error-500 focus:ring-error-500' : ''}`}
              {...register('lastName', { required: 'Last name is required' })}
            />
            {errors.lastName && <p className="form-error">{errors.lastName.message}</p>}
          </div>
        </div>
        
        <div className="mb-6">
          <label htmlFor="email" className="form-label">Email Address</label>
          <input
            type="email"
            id="email"
            className={`form-input ${errors.email ? 'border-error-500 focus:border-error-500 focus:ring-error-500' : ''}`}
            {...register('email', { 
              required: 'Email is required',
              pattern: {
                value: /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i,
                message: 'Invalid email address'
              }
            })}
          />
          {errors.email && <p className="form-error">{errors.email.message}</p>}
        </div>
        
        <div className="mb-6">
          <label htmlFor="phone" className="form-label">Phone Number (optional)</label>
          <input
            type="tel"
            id="phone"
            className="form-input"
            {...register('phone')}
          />
        </div>
        
        <div className="mb-6">
          <label htmlFor="subject" className="form-label">Subject</label>
          <input
            type="text"
            id="subject"
            className={`form-input ${errors.subject ? 'border-error-500 focus:border-error-500 focus:ring-error-500' : ''}`}
            {...register('subject', { required: 'Subject is required' })}
          />
          {errors.subject && <p className="form-error">{errors.subject.message}</p>}
        </div>
        
        <div className="mb-6">
          <label htmlFor="message" className="form-label">Message</label>
          <textarea
            id="message"
            rows="5"
            className={`form-input ${errors.message ? 'border-error-500 focus:border-error-500 focus:ring-error-500' : ''}`}
            {...register('message', { 
              required: 'Message is required',
              minLength: {
                value: 10,
                message: 'Message must be at least 10 characters long'
              }
            })}
          ></textarea>
          {errors.message && <p className="form-error">{errors.message.message}</p>}
        </div>
        
        <button
          type="submit"
          className="btn btn-primary w-full"
          disabled={isSubmitting}
        >
          {isSubmitting ? (
            <span className="flex items-center justify-center">
              <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
              </svg>
              Sending...
            </span>
          ) : 'Send Message'}
        </button>
      </form>
    </motion.div>
  )
}

export default ContactForm