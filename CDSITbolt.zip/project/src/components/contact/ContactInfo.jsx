import { FaMapMarkerAlt, FaEnvelope, FaFacebook, FaTwitter, FaLinkedin, FaInstagram } from 'react-icons/fa'
import { motion } from 'framer-motion'

const ContactInfo = () => {
  return (
    <motion.div 
      className="bg-primary-500 text-white rounded-lg shadow-lg p-8"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <h3 className="text-2xl font-bold text-white mb-6">Contact Information</h3>
      
      <div className="space-y-6">
        <div className="flex items-start">
          <FaMapMarkerAlt className="w-6 h-6 text-white mr-4 mt-1" />
          <div>
            <h4 className="text-lg font-semibold text-white mb-1">Our Office</h4>
            <address className="not-italic text-gray-200">
              Client Deposit Services LLC<br />
              175 SW 7th Street STE 1517-1204<br />
              Miami, FL 33130
            </address>
          </div>
        </div>
        
        <div className="flex items-start">
          <FaEnvelope className="w-6 h-6 text-white mr-4 mt-1" />
          <div>
            <h4 className="text-lg font-semibold text-white mb-1">Email Us</h4>
            <a 
              href="mailto:clientdepositservices@gmail.com" 
              className="text-gray-200 hover:text-white transition-colors duration-300"
            >
              clientdepositservices@gmail.com
            </a>
          </div>
        </div>
        
        <div>
          <h4 className="text-lg font-semibold text-white mb-3">Connect With Us</h4>
          <div className="flex space-x-4">
            <a 
              href="#" 
              className="bg-white bg-opacity-20 hover:bg-opacity-30 text-white p-3 rounded-full transition-all duration-300"
              aria-label="Facebook"
            >
              <FaFacebook className="w-5 h-5" />
            </a>
            <a 
              href="#" 
              className="bg-white bg-opacity-20 hover:bg-opacity-30 text-white p-3 rounded-full transition-all duration-300"
              aria-label="Twitter"
            >
              <FaTwitter className="w-5 h-5" />
            </a>
            <a 
              href="#" 
              className="bg-white bg-opacity-20 hover:bg-opacity-30 text-white p-3 rounded-full transition-all duration-300"
              aria-label="LinkedIn"
            >
              <FaLinkedin className="w-5 h-5" />
            </a>
            <a 
              href="#" 
              className="bg-white bg-opacity-20 hover:bg-opacity-30 text-white p-3 rounded-full transition-all duration-300"
              aria-label="Instagram"
            >
              <FaInstagram className="w-5 h-5" />
            </a>
          </div>
        </div>
      </div>
      
      <div className="mt-10">
        <h4 className="text-lg font-semibold text-white mb-3">Business Hours</h4>
        <ul className="space-y-2 text-gray-200">
          <li className="flex justify-between">
            <span>Monday - Friday</span>
            <span>9:00 AM - 6:00 PM</span>
          </li>
          <li className="flex justify-between">
            <span>Saturday</span>
            <span>10:00 AM - 2:00 PM</span>
          </li>
          <li className="flex justify-between">
            <span>Sunday</span>
            <span>Closed</span>
          </li>
        </ul>
      </div>
    </motion.div>
  )
}

export default ContactInfo