import { motion } from 'framer-motion'
import { useInView } from 'react-intersection-observer'

const credentials = [
  {
    id: 1,
    title: "Microsoft Certified Partner",
    logo: "https://upload.wikimedia.org/wikipedia/commons/4/44/Microsoft_logo.svg",
    description: "Recognized for expertise in Microsoft technologies and solutions."
  },
  {
    id: 2,
    title: "Amazon Web Services Select Partner",
    logo: "https://upload.wikimedia.org/wikipedia/commons/9/93/Amazon_Web_Services_Logo.svg",
    description: "Certified to design, deploy, and manage applications on AWS."
  },
  {
    id: 3,
    title: "Google Cloud Partner",
    logo: "https://upload.wikimedia.org/wikipedia/commons/5/51/Google_Cloud_logo.svg",
    description: "Specialized in Google Cloud infrastructure and services."
  },

]

const Credentials = () => {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1
  })

  return (
    <section className="py-16 bg-gray-100" ref={ref}>
      <div className="container">
        <motion.div 
          className="max-w-3xl mx-auto text-center mb-12"
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
          transition={{ duration: 0.6 }}
        >
          <h2 className="text-3xl font-bold text-primary-500 mb-4">Our Credentials</h2>
          <p className="text-lg text-gray-600">
            We're proud to be recognized by industry leaders for our expertise and quality of service.
          </p>
        </motion.div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {credentials.map((credential, index) => (
            <motion.div
              key={credential.id}
              className="bg-white p-6 rounded-lg shadow-md text-center"
              initial={{ opacity: 0, y: 20 }}
              animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
            >
              <div className="h-16 flex items-center justify-center mb-4">
                <img 
                  src={credential.logo} 
                  alt={credential.title} 
                  className="h-full w-auto object-contain"
                />
              </div>
              <h3 className="text-lg font-semibold text-primary-500 mb-2">{credential.title}</h3>
              <p className="text-gray-600">{credential.description}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}

export default Credentials