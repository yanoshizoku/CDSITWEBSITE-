import { motion } from 'framer-motion'
import { useInView } from 'react-intersection-observer'
import { FaLinkedin, FaTwitter, FaEnvelope } from 'react-icons/fa'

const teamMembers = [
  {
    id: 1,
    name: "Michael Rodriguez",
    position: "Founder & CEO",
    bio: "With over 15 years of experience in IT consulting and software development, Michael leads our team with a vision for innovative technology solutions.",
    image: "https://images.pexels.com/photos/2379005/pexels-photo-2379005.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
  },
  {
    id: 2,
    name: "Sarah Johnson",
    position: "CTO",
    bio: "Sarah brings her extensive knowledge in systems architecture and emerging technologies to lead our technical strategy and implementation.",
    image: "https://images.pexels.com/photos/5876695/pexels-photo-5876695.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
  },
  {
    id: 3,
    name: "David Martinez",
    position: "Business Development Director",
    bio: "David's background in business management and strategic planning helps our clients align their technology investments with business objectives.",
    image: "https://images.pexels.com/photos/2182970/pexels-photo-2182970.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
  },
  {
    id: 4,
    name: "Jessica Williams",
    position: "Marketing & Social Media Director",
    bio: "Jessica leads our social media strategy services, bringing creativity and data-driven approaches to help clients build their online presence.",
    image: "https://images.pexels.com/photos/762020/pexels-photo-762020.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
  }
]

const Team = () => {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1
  })

  return (
    <section className="py-16 bg-gray-50" ref={ref}>
      <div className="container">
        <motion.div 
          className="max-w-3xl mx-auto text-center mb-12"
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
          transition={{ duration: 0.6 }}
        >
          <h2 className="text-3xl font-bold text-primary-500 mb-4">Our Team</h2>
          <p className="text-lg text-gray-600">
            Meet our team of experienced professionals dedicated to delivering exceptional technology solutions for your business.
          </p>
        </motion.div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {teamMembers.map((member, index) => (
            <motion.div
              key={member.id}
              className="bg-white rounded-lg shadow-md overflow-hidden"
              initial={{ opacity: 0, y: 30 }}
              animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
            >
              <img 
                src={member.image} 
                alt={member.name} 
                className="w-full h-60 object-cover object-center"
              />
              <div className="p-6">
                <h3 className="text-xl font-semibold text-primary-500">{member.name}</h3>
                <p className="text-gray-600 mb-4">{member.position}</p>
                <p className="text-gray-700 mb-4">{member.bio}</p>
                <div className="flex space-x-4">
                  <a 
                    href="#" 
                    className="text-gray-400 hover:text-primary-500 transition-colors duration-300"
                    aria-label={`${member.name}'s LinkedIn`}
                  >
                    <FaLinkedin className="w-5 h-5" />
                  </a>
                  <a 
                    href="#" 
                    className="text-gray-400 hover:text-primary-500 transition-colors duration-300"
                    aria-label={`${member.name}'s Twitter`}
                  >
                    <FaTwitter className="w-5 h-5" />
                  </a>
                  <a 
                    href="#" 
                    className="text-gray-400 hover:text-primary-500 transition-colors duration-300"
                    aria-label={`Email ${member.name}`}
                  >
                    <FaEnvelope className="w-5 h-5" />
                  </a>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}

export default Team