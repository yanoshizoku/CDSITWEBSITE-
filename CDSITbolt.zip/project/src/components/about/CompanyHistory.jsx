import { motion } from 'framer-motion'
import { useInView } from 'react-intersection-observer'

const CompanyHistory = () => {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1
  })

  return (
    <section className="py-16" ref={ref}>
      <div className="container">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            animate={inView ? { opacity: 1, x: 0 } : { opacity: 0, x: -30 }}
            transition={{ duration: 0.6 }}
          >
            <h2 className="text-3xl font-bold text-primary-500 mb-6">Our Story</h2>
            <div className="space-y-4">
              <p className="text-gray-700">
                CDS IT Consulting is a premier technology services provider based in Miami, Florida. Founded in 2025 as the consulting division of Client Deposit Services LLC, we've rapidly built a reputation for delivering innovative, high-impact solutions that drive business growth and operational efficiency.
              </p>
              <p className="text-gray-700">
                Despite being a young company, we have established a strong global network of expert freelancers across various technology domains. This flexible model allows us to scale quickly and bring in top-tier talent as needed — ensuring each project is handled by professionals with the exact expertise required.
              </p>
              <p className="text-gray-700">
                Our team combines deep technical knowledge with a consultative approach, offering tailored IT solutions that align with your unique business goals. We prioritize long-term partnerships, working closely with clients to understand challenges and deliver measurable results.
              </p>
            </div>
          </motion.div>
          
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            animate={inView ? { opacity: 1, x: 0 } : { opacity: 0, x: 30 }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            <img 
              src="https://images.pexels.com/photos/3184339/pexels-photo-3184339.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2" 
              alt="CDS IT Consulting Team" 
              className="rounded-lg shadow-lg w-full h-auto"
            />
          </motion.div>
        </div>
      </div>
    </section>
  )
}

export default CompanyHistory