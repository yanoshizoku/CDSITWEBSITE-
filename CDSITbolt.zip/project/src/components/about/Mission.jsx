import { motion } from 'framer-motion'
import { useInView } from 'react-intersection-observer'

const Mission = () => {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1
  })

  return (
    <section className="py-16 bg-primary-500 text-white" ref={ref}>
      <div className="container">
        <motion.div 
          className="max-w-3xl mx-auto text-center"
          initial={{ opacity: 0, y: 30 }}
          animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
          transition={{ duration: 0.6 }}
        >
          <h2 className="text-3xl font-bold text-white mb-8">Our Mission</h2>
          <p className="text-xl leading-relaxed mb-8">
            Our mission is to empower businesses through innovative technology solutions that drive growth, efficiency, and competitive advantage. We are committed to understanding each client's unique challenges and delivering tailored solutions that exceed expectations.
          </p>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-12">
            <div className="bg-white bg-opacity-10 p-6 rounded-lg">
              <div className="w-16 h-16 bg-white text-primary-500 rounded-full flex items-center justify-center mx-auto mb-4">
                <svg 
                  className="w-8 h-8" 
                  fill="currentColor" 
                  viewBox="0 0 20 20" 
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path 
                    fillRule="evenodd" 
                    d="M7 3.5A1.5 1.5 0 018.5 2h3.879a1.5 1.5 0 011.06.44l3.122 3.12A1.5 1.5 0 0117 6.622V16.5a1.5 1.5 0 01-1.5 1.5h-10A1.5 1.5 0 014 16.5v-13A1.5 1.5 0 015.5 2h1A1.5 1.5 0 017 3.5zm-2 13V6H5v10.5a.5.5 0 00.5.5H15v.5a.5.5 0 01-.5.5h-10a.5.5 0 01-.5-.5v-13a.5.5 0 01.5-.5H7v-.5zm8.5-11h-3a.5.5 0 01-.5-.5v-3h.5a.5.5 0 01.354.146l3 3a.5.5 0 01.146.354v.5z" 
                    clipRule="evenodd" 
                  />
                </svg>
              </div>
              <h3 className="text-xl font-semibold mb-3">Excellence</h3>
              <p>
                We are committed to delivering the highest quality services and solutions that meet or exceed industry standards and client expectations.
              </p>
            </div>
            
            <div className="bg-white bg-opacity-10 p-6 rounded-lg">
              <div className="w-16 h-16 bg-white text-primary-500 rounded-full flex items-center justify-center mx-auto mb-4">
                <svg 
                  className="w-8 h-8" 
                  fill="currentColor" 
                  viewBox="0 0 20 20" 
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path 
                    fillRule="evenodd" 
                    d="M3.172 5.172a4 4 0 015.656 0L10 6.343l1.172-1.171a4 4 0 115.656 5.656L10 17.657l-6.828-6.829a4 4 0 010-5.656z" 
                    clipRule="evenodd" 
                  />
                </svg>
              </div>
              <h3 className="text-xl font-semibold mb-3">Integrity</h3>
              <p>
                We operate with honesty, transparency, and ethical business practices in all our interactions with clients, partners, and employees.
              </p>
            </div>
            
            <div className="bg-white bg-opacity-10 p-6 rounded-lg">
              <div className="w-16 h-16 bg-white text-primary-500 rounded-full flex items-center justify-center mx-auto mb-4">
                <svg 
                  className="w-8 h-8" 
                  fill="currentColor" 
                  viewBox="0 0 20 20" 
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path 
                    fillRule="evenodd" 
                    d="M11.3 1.046A1 1 0 0112 2v5h4a1 1 0 01.82 1.573l-7 10A1 1 0 018 18v-5H4a1 1 0 01-.82-1.573l7-10a1 1 0 011.12-.38z" 
                    clipRule="evenodd" 
                  />
                </svg>
              </div>
              <h3 className="text-xl font-semibold mb-3">Innovation</h3>
              <p>
                We continuously explore new technologies and methodologies to bring innovative solutions that address evolving business challenges.
              </p>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  )
}

export default Mission