import { Link } from 'react-router-dom'
import { motion } from 'framer-motion'

const Hero = () => {
  return (
    <section className="relative bg-gradient-to-r from-primary-600 to-primary-500 pt-24 pb-16 md:pt-32 md:pb-24">
      {/* Background pattern */}
      <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTQ0MCIgaGVpZ2h0PSI3NjgiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGcgZmlsbD0ibm9uZSIgZmlsbC1ydWxlPSJldmVub2RkIj48cmVjdCBmaWxsPSIjMEEyNDYzIiB3aWR0aD0iMTQ0MCIgaGVpZ2h0PSI3NjgiLz48ZyBvcGFjaXR5PSIuMDUiIGZpbGw9IiNGRkYiPjxwYXRoIGQ9Ik02NTkuNSA1MDBMMTEwMCAxODAgMTMyMCAzMzAgODgwIDY1MCIvPjxwYXRoIGQ9Ik0xMTAwIDE4MEw1NTAgNTAwIDMzMCAzMzAgODgwIDEwIi8+PHBhdGggZD0iTTg4MCA2NTBMNDMwIDk3MCAyMTAgODIwIDY2MCA1MDAiLz48cGF0aCBkPSJNODgwIDEwTDIxMCAzMzAtMjQwIDEwIDQzMC0zMTAiLz48cGF0aCBkPSJNNDMwIDk3MEw0My40IDEyNzItMjQwIDEwMjIgMTQ2LjYgNzIwIi8+PC9nPjwvZz48L3N2Zz4=')] opacity-20 bg-cover bg-center mix-blend-overlay"></div>
      
      <div className="container relative z-10">
        <div className="flex flex-col md:flex-row items-center">
          <div className="md:w-1/2 text-center md:text-left">
            <motion.h1 
              className="text-white text-4xl md:text-5xl font-bold leading-tight mb-6"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
            >
              Empowering Business <br/>Through Technology
            </motion.h1>
            
            <motion.p 
              className="text-gray-100 text-lg md:text-xl mb-8 max-w-lg mx-auto md:mx-0"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
            >
              CDS IT Consulting provides innovative technology solutions to help your business adapt, grow, and succeed in today's competitive market.
            </motion.p>
            
            <motion.div 
              className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4 justify-center md:justify-start"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.4 }}
            >
              <Link to="/services" className="btn bg-white text-primary-500 hover:bg-gray-100">
                Our Services
              </Link>
              <Link to="/contact" className="btn bg-transparent text-white border-2 border-white hover:bg-white hover:text-primary-500">
                Get in Touch
              </Link>
            </motion.div>
          </div>
          
          <motion.div 
            className="md:w-1/2 mt-12 md:mt-0"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.6 }}
          >
            <img 
              src="https://images.pexels.com/photos/3183150/pexels-photo-3183150.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2" 
              alt="IT Professionals working together" 
              className="w-full h-auto rounded-lg shadow-xl" 
            />
          </motion.div>
        </div>
      </div>
    </section>
  )
}

export default Hero