import { Link } from 'react-router-dom'
import { motion } from 'framer-motion'
import { useInView } from 'react-intersection-observer'
import SectionHeading from '../common/SectionHeading'

const About = () => {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1
  })

  return (
    <section className="section bg-white" ref={ref}>
      <div className="container">
        <div className="flex flex-col lg:flex-row items-center gap-12">
          <motion.div 
            className="lg:w-1/2"
            initial={{ opacity: 0, x: -30 }}
            animate={inView ? { opacity: 1, x: 0 } : { opacity: 0, x: -30 }}
            transition={{ duration: 0.6 }}
          >
            <img 
              src="https://images.pexels.com/photos/3182834/pexels-photo-3182834.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2" 
              alt="CDS IT Consulting team meeting" 
              className="rounded-lg shadow-lg w-full h-auto" 
            />
          </motion.div>
          
          <div className="lg:w-1/2">
            <SectionHeading
              title="About CDS IT Consulting"
              subtitle="We help businesses navigate the complex world of technology."
            />
            
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
              transition={{ duration: 0.6, delay: 0.2 }}
            >
              <p className="text-gray-600 mb-6">
                Founded in 2025 as the consulting division of Client Deposit Services LLC, we've rapidly built a reputation for delivering innovative, high-impact solutions that drive business growth and operational efficiency.
              </p>
              
              <p className="text-gray-600 mb-6">
                Our team combines deep technical knowledge with a consultative approach, offering tailored IT solutions that align with your unique business goals. Whether you need help with digital transformation, software integration, or strategic IT planning, we're ready to support your success.
              </p>
              
              <div className="mt-8">
                <Link to="/about" className="btn btn-primary">
                  Learn More About Us
                </Link>
              </div>
            </motion.div>
          </div>
        </div>
      </div>
    </section>
  )
}

export default About