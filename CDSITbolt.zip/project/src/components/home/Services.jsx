import { Link } from 'react-router-dom'
import { FaLaptopCode, FaCogs, FaChartLine, FaHashtag } from 'react-icons/fa'
import { motion } from 'framer-motion'
import { useInView } from 'react-intersection-observer'
import SectionHeading from '../common/SectionHeading'

const services = [
  {
    id: 1,
    title: "Information Technology Consulting",
    description: "Expert guidance on IT infrastructure, systems integration, and technology strategy to align with your business goals.",
    icon: FaLaptopCode,
    color: "primary",
    delay: 0.1
  },
  {
    id: 2,
    title: "Software Development",
    description: "Custom software solutions designed to streamline operations, improve efficiency, and enhance user experience.",
    icon: FaCogs,
    color: "secondary",
    delay: 0.2
  },
  {
    id: 3,
    title: "Business Management",
    description: "Strategic business consulting to optimize operations, reduce costs, and maximize growth potential.",
    icon: FaChartLine,
    color: "accent",
    delay: 0.3
  },
  {
    id: 4,
    title: "Social Media Strategy",
    description: "Comprehensive social media solutions to build brand awareness, engage customers, and drive business growth.",
    icon: FaHashtag,
    color: "success",
    delay: 0.4
  }
]

const Services = () => {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1
  })

  const container = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  }

  const item = {
    hidden: { opacity: 0, y: 20 },
    show: { opacity: 1, y: 0, transition: { duration: 0.5 } }
  }

  return (
    <section className="section bg-gray-50" ref={ref}>
      <div className="container">
        <SectionHeading
          title="Our Services"
          subtitle="We provide comprehensive technology solutions to help businesses thrive in the digital landscape."
          centered
        />
        
        <motion.div 
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8"
          variants={container}
          initial="hidden"
          animate={inView ? "show" : "hidden"}
        >
          {services.map((service) => {
            const IconComponent = service.icon
            
            return (
              <motion.div
                key={service.id}
                className="card hover:translate-y-[-10px]"
                variants={item}
              >
                <div className={`w-14 h-14 flex items-center justify-center rounded-full mb-6 bg-${service.color}-500 bg-opacity-10`}>
                  <IconComponent className={`w-6 h-6 text-${service.color}-500`} />
                </div>
                <h3 className="text-xl font-semibold mb-3">{service.title}</h3>
                <p className="text-gray-600 mb-4">{service.description}</p>
                <Link 
                  to="/services" 
                  className="text-primary-500 font-medium hover:text-primary-600 inline-flex items-center"
                >
                  Learn more
                  <svg 
                    className="w-4 h-4 ml-1" 
                    fill="none" 
                    stroke="currentColor" 
                    viewBox="0 0 24 24" 
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path 
                      strokeLinecap="round" 
                      strokeLinejoin="round" 
                      strokeWidth={2} 
                      d="M9 5l7 7-7 7" 
                    />
                  </svg>
                </Link>
              </motion.div>
            )
          })}
        </motion.div>
        
        <div className="mt-12 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
            transition={{ delay: 0.6, duration: 0.5 }}
          >
            <Link to="/services" className="btn btn-primary">
              View All Services
            </Link>
          </motion.div>
        </div>
      </div>
    </section>
  )
}

export default Services