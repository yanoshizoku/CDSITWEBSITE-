import { Link } from 'react-router-dom'
import { motion } from 'framer-motion'
import { useInView } from 'react-intersection-observer'

const CTA = () => {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1
  })

  return (
    <section className="py-20 bg-gray-100" ref={ref}>
      <div className="container">
        <motion.div 
          className="bg-gradient-to-r from-primary-500 to-secondary-500 rounded-2xl p-12 text-center text-white shadow-xl"
          initial={{ opacity: 0, y: 30 }}
          animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
          transition={{ duration: 0.6 }}
        >
          <h2 className="text-3xl md:text-4xl font-bold mb-6 text-white">Ready to transform your business?</h2>
          <p className="text-xl md:text-2xl text-gray-100 mb-8 max-w-2xl mx-auto">
            Let's work together to create innovative solutions that drive your business forward.
          </p>
          <div className="flex flex-col sm:flex-row justify-center space-y-4 sm:space-y-0 sm:space-x-6">
            <Link 
              to="/contact" 
              className="btn bg-white text-primary-500 hover:bg-gray-100"
            >
              Contact Us
            </Link>
            <Link 
              to="/services" 
              className="btn bg-transparent border-2 border-white hover:bg-white hover:text-primary-500"
            >
              Explore Services
            </Link>
          </div>
        </motion.div>
      </div>
    </section>
  )
}

export default CTA