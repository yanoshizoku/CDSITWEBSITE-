import { FaLaptopCode, FaCogs, FaChartLine, FaHashtag } from 'react-icons/fa'
import { motion } from 'framer-motion'
import { useInView } from 'react-intersection-observer'

const services = [
  {
    id: 1,
    title: "Information Technology Consulting",
    description: "Our IT consulting services provide expert guidance to help businesses leverage technology for maximum efficiency and competitive advantage.",
    icon: FaLaptopCode,
    color: "primary",
    features: [
      "IT infrastructure assessment and optimization",
      "Technology strategy development",
      "Systems integration and migration planning",
      "IT project management",
      "Cloud computing solutions",
      "Cybersecurity assessment and planning"
    ],
    benefits: [
      "Align IT strategy with business goals",
      "Reduce operational costs and increase efficiency",
      "Enhance security and minimize risk",
      "Streamline technology adoption and implementation",
      "Access expert guidance on emerging technologies"
    ]
  },
  {
    id: 2,
    title: "Software Development",
    description: "We design and develop custom software solutions tailored to your unique business needs and processes.",
    icon: FaCogs,
    color: "secondary",
    features: [
      "Custom application development",
      "Web and mobile app development",
      "Database design and development",
      "API development and integration",
      "Legacy system modernization",
      "Quality assurance and testing"
    ],
    benefits: [
      "Streamline operations with tailored solutions",
      "Improve customer experience and engagement",
      "Enhance data collection and analysis capabilities",
      "Integrate disparate systems seamlessly",
      "Gain competitive advantage through digital innovation"
    ]
  },
  {
    id: 3,
    title: "Business Management",
    description: "Our strategic business management consulting helps optimize operations, reduce costs, and drive sustainable growth.",
    icon: FaChartLine,
    color: "accent",
    features: [
      "Business process optimization",
      "Operational efficiency analysis",
      "Strategic planning and implementation",
      "Change management",
      "Performance metrics and KPI development",
      "Financial analysis and planning"
    ],
    benefits: [
      "Identify and eliminate operational inefficiencies",
      "Develop data-driven decision-making processes",
      "Improve resource allocation and utilization",
      "Build scalable operational frameworks",
      "Accelerate business growth and profitability"
    ]
  },
  {
    id: 4,
    title: "Social Media Strategy",
    description: "We create comprehensive social media strategies to build your brand, engage customers, and drive business growth.",
    icon: FaHashtag,
    color: "success",
    features: [
      "Social media audit and competitive analysis",
      "Platform-specific strategy development",
      "Content creation and curation",
      "Audience targeting and growth",
      "Social media advertising campaigns",
      "Analytics and performance reporting"
    ],
    benefits: [
      "Increase brand awareness and visibility",
      "Build engaged online communities",
      "Generate qualified leads and conversions",
      "Improve customer service and satisfaction",
      "Gain valuable market insights and feedback"
    ]
  }
]

const ServiceDetails = () => {
  const container = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2
      }
    }
  }

  const item = {
    hidden: { opacity: 0, y: 20 },
    show: { opacity: 1, y: 0, transition: { duration: 0.5 } }
  }

  return (
    <motion.div 
      className="space-y-24"
      variants={container}
      initial="hidden"
      animate="show"
    >
      {services.map((service, index) => {
        const [ref, inView] = useInView({
          triggerOnce: true,
          threshold: 0.1
        })
        
        const IconComponent = service.icon
        const isEven = index % 2 === 0
        
        return (
          <section 
            key={service.id} 
            ref={ref}
            className={`grid md:grid-cols-2 gap-12 items-center ${isEven ? '' : 'md:grid-flow-dense'}`}
          >
            <motion.div
              className={isEven ? 'md:order-1' : 'md:order-2'}
              initial={{ opacity: 0, x: isEven ? -30 : 30 }}
              animate={inView ? { opacity: 1, x: 0 } : { opacity: 0, x: isEven ? -30 : 30 }}
              transition={{ duration: 0.6 }}
            >
              <div className={`w-16 h-16 flex items-center justify-center rounded-full mb-6 bg-${service.color}-500 bg-opacity-10`}>
                <IconComponent className={`w-8 h-8 text-${service.color}-500`} />
              </div>
              <h2 className="text-3xl font-bold mb-4">{service.title}</h2>
              <p className="text-gray-600 text-lg mb-6">{service.description}</p>
              
              <div className="mb-8">
                <h3 className="text-xl font-semibold mb-4">Key Features</h3>
                <ul className="space-y-2">
                  {service.features.map((feature, i) => (
                    <li key={i} className="flex items-start">
                      <svg 
                        className={`w-5 h-5 text-${service.color}-500 mr-2 mt-1 flex-shrink-0`} 
                        fill="currentColor" 
                        viewBox="0 0 20 20" 
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path 
                          fillRule="evenodd" 
                          d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" 
                          clipRule="evenodd" 
                        />
                      </svg>
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>
              </div>
              
              <div>
                <h3 className="text-xl font-semibold mb-4">Benefits</h3>
                <ul className="space-y-2">
                  {service.benefits.map((benefit, i) => (
                    <li key={i} className="flex items-start">
                      <svg 
                        className={`w-5 h-5 text-${service.color}-500 mr-2 mt-1 flex-shrink-0`} 
                        fill="currentColor" 
                        viewBox="0 0 20 20" 
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path 
                          fillRule="evenodd" 
                          d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" 
                          clipRule="evenodd" 
                        />
                      </svg>
                      <span>{benefit}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </motion.div>
            
            <motion.div
              className={isEven ? 'md:order-2' : 'md:order-1'}
              initial={{ opacity: 0, x: isEven ? 30 : -30 }}
              animate={inView ? { opacity: 1, x: 0 } : { opacity: 0, x: isEven ? 30 : -30 }}
              transition={{ duration: 0.6, delay: 0.2 }}
            >
              <img 
                src={`https://images.pexels.com/photos/${index === 0 ? '3183150' : index === 1 ? '3861969' : index === 2 ? '416405' : '935979'}/pexels-photo-${index === 0 ? '3183150' : index === 1 ? '3861969' : index === 2 ? '416405' : '935979'}.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2`}
                alt={service.title}
                className="w-full h-auto rounded-lg shadow-lg"
              />
            </motion.div>
          </section>
        )
      })}
    </motion.div>
  )
}

export default ServiceDetails