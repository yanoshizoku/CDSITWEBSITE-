const Logo = ({ className = "", light = false }) => {
  return (
    <div className={`flex items-center ${className}`}>
      <svg 
        width="40" 
        height="40" 
        viewBox="0 0 40 40" 
        fill="none" 
        xmlns="http://www.w3.org/2000/svg"
      >
        <circle cx="10" cy="10" r="10" fill={light ? "#ffffff" : "#FF69B4"} />
        <circle cx="30" cy="10" r="10" fill={light ? "#ffffff" : "#FF69B4"} />
        <circle cx="10" cy="30" r="10" fill={light ? "#ffffff" : "#FF69B4"} />
        <circle cx="30" cy="30" r="10" fill={light ? "#ffffff" : "#FF69B4"} />
      </svg>
      <span className={`ml-2 text-xl font-bold ${light ? 'text-white' : 'text-gray-900'}`}>
        CDS IT
      </span>
    </div>
  )
}

export default Logo