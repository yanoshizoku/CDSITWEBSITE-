import { useState } from 'react'
import { Link, NavLink } from 'react-router-dom'
import { FaBars, FaTimes } from 'react-icons/fa'
import Logo from '../common/Logo'

const Navbar = () => {
  const [isOpen, setIsOpen] = useState(false)

  const toggleMenu = () => {
    setIsOpen(!isOpen)
  }

  const navLinkClasses = ({ isActive }) => 
    `relative px-4 py-2 text-base font-medium transition-colors duration-300 rounded-full
    ${isActive 
      ? 'text-white bg-primary-500' 
      : 'text-gray-700 hover:bg-primary-50'}`

  return (
    <header className="bg-white shadow-md py-4 fixed top-0 left-0 right-0 z-50">
      <div className="container flex items-center justify-between">
        <Link to="/" className="flex items-center">
          <Logo className="h-10 w-auto" />
        </Link>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center space-x-4">
          <NavLink to="/" className={navLinkClasses} end>
            Home
          </NavLink>
          <NavLink to="/services" className={navLinkClasses}>
            Services
          </NavLink>
          <NavLink to="/about" className={navLinkClasses}>
            About Us
          </NavLink>
          <NavLink to="/contact" className={navLinkClasses}>
            Contact
          </NavLink>
          <Link 
            to="/contact" 
            className="ml-4 px-6 py-2 bg-primary-500 text-white rounded-full hover:bg-primary-600 transition-colors duration-300"
          >
            Get a Quote
          </Link>
        </nav>

        {/* Mobile Menu Button */}
        <button 
          className="md:hidden text-gray-700 focus:outline-none" 
          onClick={toggleMenu}
          aria-label="Toggle menu"
        >
          {isOpen ? (
            <FaTimes className="h-6 w-6" />
          ) : (
            <FaBars className="h-6 w-6" />
          )}
        </button>
      </div>

      {/* Mobile Navigation */}
      <div className={`md:hidden absolute top-full left-0 right-0 bg-white shadow-md transition-transform duration-300 ease-in-out transform ${
        isOpen ? 'translate-y-0' : '-translate-y-full'
      }`}>
        <div className="container py-4 space-y-2">
          <NavLink 
            to="/" 
            className={({ isActive }) => 
              `block px-4 py-2 rounded-full text-base font-medium ${
                isActive ? 'bg-primary-500 text-white' : 'text-gray-700 hover:bg-primary-50'
              }`
            }
            onClick={toggleMenu}
            end
          >
            Home
          </NavLink>
          <NavLink 
            to="/services" 
            className={({ isActive }) => 
              `block px-4 py-2 rounded-full text-base font-medium ${
                isActive ? 'bg-primary-500 text-white' : 'text-gray-700 hover:bg-primary-50'
              }`
            }
            onClick={toggleMenu}
          >
            Services
          </NavLink>
          <NavLink 
            to="/about" 
            className={({ isActive }) => 
              `block px-4 py-2 rounded-full text-base font-medium ${
                isActive ? 'bg-primary-500 text-white' : 'text-gray-700 hover:bg-primary-50'
              }`
            }
            onClick={toggleMenu}
          >
            About Us
          </NavLink>
          <NavLink 
            to="/contact" 
            className={({ isActive }) => 
              `block px-4 py-2 rounded-full text-base font-medium ${
                isActive ? 'bg-primary-500 text-white' : 'text-gray-700 hover:bg-primary-50'
              }`
            }
            onClick={toggleMenu}
          >
            Contact
          </NavLink>
          <Link 
            to="/contact" 
            className="block px-6 py-2 bg-primary-500 text-white rounded-full text-center hover:bg-primary-600 transition-colors duration-300"
            onClick={toggleMenu}
          >
            Get a Quote
          </Link>
        </div>
      </div>
    </header>
  )
}

export default Navbar