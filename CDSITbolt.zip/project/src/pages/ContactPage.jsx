import { motion } from 'framer-motion'
import ContactForm from '../components/contact/ContactForm'
import ContactInfo from '../components/contact/ContactInfo'
import GoogleMap from '../components/contact/GoogleMap'

const ContactPage = () => {
  return (
    <>
      <section className="pt-32 pb-16 bg-gradient-to-r from-primary-600 to-primary-500">
        <div className="container">
          <motion.div 
            className="max-w-3xl mx-auto text-center text-white"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-6">Contact Us</h1>
            <p className="text-xl text-gray-100">
              Have questions or ready to start a project? Reach out to our team today.
            </p>
          </motion.div>
        </div>
      </section>
      
      <section className="py-16">
        <div className="container">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            <ContactForm />
            <ContactInfo />
          </div>
        </div>
      </section>
      
      <section className="pb-16">
        <div className="container">
          <motion.h2 
            className="text-2xl font-bold text-primary-500 mb-6"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            Our Location
          </motion.h2>
          <GoogleMap />
        </div>
      </section>
    </>
  )
}

export default ContactPage