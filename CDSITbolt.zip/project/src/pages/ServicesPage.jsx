import { motion } from 'framer-motion'
import ServiceDetails from '../components/services/ServiceDetails'
import CTA from '../components/home/CTA'
import SectionHeading from '../components/common/SectionHeading'

const ServicesPage = () => {
  return (
    <>
      <section className="pt-32 pb-16 bg-gradient-to-r from-primary-600 to-primary-500">
        <div className="container">
          <motion.div 
            className="max-w-3xl mx-auto text-center text-white"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-6">Our Services</h1>
            <p className="text-xl text-gray-100">
              Comprehensive technology solutions designed to empower your business and drive growth.
            </p>
          </motion.div>
        </div>
      </section>

      <section className="py-16">
        <div className="container">
          <SectionHeading
            title="What We Offer"
            subtitle="We provide a wide range of technology services tailored to meet the unique needs of your business."
            centered
          />
          
          <ServiceDetails />
        </div>
      </section>
      
      <CTA />
    </>
  )
}

export default ServicesPage