import Hero from '../components/home/Hero'
import Services from '../components/home/Services'
import About from '../components/home/About'
import Testimonials from '../components/home/Testimonials'
import CTA from '../components/home/CTA'

const HomePage = () => {
  return (
    <>
      <Hero />
      <Services />
      <About />
      <Testimonials />
      <CTA />
    </>
  )
}

export default HomePage