import { motion } from 'framer-motion'
import CompanyHistory from '../components/about/CompanyHistory'
import Mission from '../components/about/Mission'
import Team from '../components/about/Team'
import Values from '../components/about/Values'
import Credentials from '../components/about/Credentials'
import CTA from '../components/home/CTA'

const AboutPage = () => {
  return (
    <>
      <section className="pt-32 pb-16 bg-gradient-to-r from-primary-600 to-primary-500">
        <div className="container">
          <motion.div 
            className="max-w-3xl mx-auto text-center text-white"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-6">About Us</h1>
            <p className="text-xl text-gray-100">
              Learn more about CDS IT Consulting, our team, and our commitment to empowering businesses through technology.
            </p>
          </motion.div>
        </div>
      </section>
      
      <CompanyHistory />
      <Mission />
      <Values />
      <Credentials />
      <CTA />
    </>
  )
}

export default AboutPage